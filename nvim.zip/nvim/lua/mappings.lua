require("nvchad.mappings")

-- add yours here

local map = vim.keymap.set
map("n", "<leader>n", "<cmd>Neotree filesystem reveal left<CR>")
map("n", "<C-R>n", "<cmd>Neotree filesystem reveal left<CR>")
map("n", ";", ":", { desc = "CMD enter command mode" })
map("i", "jk", "<ESC>")
map("n", "<leader>r", function()
	vim.cmd("w")
	local extension = vim.fn.expand("%:e")
	if extension == "py" then
		vim.cmd(":term python3 %")
	elseif extension == "sh" then
		vim.cmd(":term sh %")
	elseif extension == "cpp" then
		vim.cmd(":!g++ % -o %:r")
		vim.cmd(":term ./%:r")
	elseif extension == "go" then
		vim.cmd(":term go run %")
	elseif extension == "rs" then
		vim.cmd(":!rustc %")
		vim.cmd(":term ./%:r")
	else
		print("No runner configured for ." .. extension .. " files")
	end
	vim.cmd("startinsert")
end, { desc = "Run file based on extension" })

map({ "i", "n" }, "<C-Tab>", function()
	local nvim_tree = require("nvim-tree.api")
	local current_window = vim.api.nvim_get_current_win()
	local nvim_tree_window = nvim_tree.tree.get_window()
	if current_window == nvim_tree_window then
		vim.api.nvim_set_current_win(vim.api.nvim_list_wins()[2])
	else
		nvim_tree.tree.focus()
	end
end)
-- map({ "n", "i", "v" }, "<C-s>", "<cmd> w <cr>")
