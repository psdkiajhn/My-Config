local augroup = vim.api.nvim_create_augroup("LspFormatting", {})
local null_ls = require "null-ls"

local rustfmt = {
  method = null_ls.methods.FORMATTING,
  filetypes = { "rust" },
  generator = null_ls.generator {
    command = "rustfmt",
    args = { "--emit", "stdout" },
    to_stdin = true,
  },
}

local beautysh = {
  method = null_ls.methods.FORMATTING,
  filetypes = { "sh", "bash", "zsh" },
  generator = null_ls.generator {
    command = "beautysh",
    args = { "-" },
    to_stdin = true,
  },
}

local opts = {
  sources = {
    null_ls.builtins.formatting.clang_format,
    null_ls.builtins.formatting.black,
    null_ls.builtins.formatting.stylua,
    beautysh,
    null_ls.builtins.formatting.gofumpt,
    rustfmt,
  },
  on_attach = function(client, bufnr)
    if client.supports_method "textDocument/formatting" then
      vim.api.nvim_clear_autocmds {
        group = augroup,
        buffer = bufnr,
      }
      vim.api.nvim_create_autocmd("BufWritePre", {
        group = augroup,
        buffer = bufnr,
        callback = function()
          vim.lsp.buf.format { bufnr = bufnr }
        end,
      })
    end
  end,
}

return opts
