require "nvchad.options"

vim.opt.relativenumber = true

-- vim.schedule(function()
--   vim.cmd "wincmd p"
-- end)

vim.api.nvim_create_autocmd("FileType", {
  pattern = "kdl",
  callback = function()
    vim.opt.commentstring = "// %s"
  end,
  desc = "Change commentstring for c/c++ files",
})

vim.api.nvim_create_autocmd("FileType", {
  pattern = "sh",
  callback = function()
    vim.lsp.start {
      name = "bash-language-server",
      cmd = { "bash-language-server", "start" },
    }
  end,
})

vim.cmd [[
    augroup cpp_template
    autocmd!
    autocmd BufNewFile *.cpp 0r /home/psdk/.config/nvim/main.cpp | lua vim.api.nvim_win_set_cursor(0, {26, 2})
    augroup END
]]

-- add yours here!

-- local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
