require "nvchad.options"

vim.opt.relativenumber = true


vim.cmd [[
  augroup cpp_template
    autocmd!
    autocmd BufNewFile *.cpp 0r /home/psdk/.config/nvim/main.cpp | lua vim.api.nvim_win_set_cursor(0, {26, 2})
  augroup END
]]

-- add yours here!

-- local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
