#include <bits/stdc++.h>
using namespace std;

// clang-format off
#define ll long long
#define pb push_back
#define f first
#define s second
#define DFA(arr) for (auto i : arr)cout << i;cout << endl;
#define FOR(i, a) for (int i = 0; i < a; i++)
#define F0R(i, a, b) for (int i = a; i < b; i++)
#define FORS(i, a, s) for (int i = 0; i < a; i += s)
#define F0RS(i, a, b, s) for (int i = a; i < b; i += s)
#define FAR(i,arr) for(auto &i:arr)
#define FAN(i,arr) for(auto i:arr)
// clang-format on

/*██████╗ ███████╗██████╗ ██╗  ██╗*/
/*██╔══██╗██╔════╝██╔══██╗██║ ██╔╝*/
/*██████╔╝███████╗██║  ██║█████╔╝ */
/*██╔═══╝ ╚════██║██║  ██║██╔═██╗ */
/*██║     ███████║██████╔╝██║  ██╗*/
/*╚═╝     ╚══════╝╚═════╝ ╚═╝  ╚═╝*/

int main() {

  return 0;
}
